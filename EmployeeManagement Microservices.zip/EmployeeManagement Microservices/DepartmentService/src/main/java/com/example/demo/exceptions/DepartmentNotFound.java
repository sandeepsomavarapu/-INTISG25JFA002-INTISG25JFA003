package com.example.demo.exceptions;

public class DepartmentNotFound extends Exception {
	public DepartmentNotFound(String message) {
		super(message);
	}
}
